export default {
    __esModule: true,
    default: 'test-file-stub',
};