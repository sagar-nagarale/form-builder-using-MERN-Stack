import React from "react"
export default function Divider(){
    return(
        <div style={{height:'1px'}} className="w-full my-2 bg-gray-200"></div>
    )
}